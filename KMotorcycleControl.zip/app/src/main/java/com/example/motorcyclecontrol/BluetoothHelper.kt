package com.example.motorcyclecontrol

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.os.Handler
import android.os.Looper
import java.io.IOException
import java.io.OutputStream
import java.util.UUID

/**
 * يتعامل مع الاتصال عبر Bluetooth الكلاسيكي (SPP) مع ESP32
 * الذي يستخدم BluetoothSerial، ويرسل أوامر بحرف واحد (مثل كود المستخدم الأصلي).
 */
class BluetoothHelper(
    private val onStatusChanged: (Boolean) -> Unit,
    private val onLog: (String) -> Unit
) {
    // نفس معرّف خدمة SPP القياسي المستخدم مع BluetoothSerial على ESP32
    private val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    private var socket: BluetoothSocket? = null
    private var outputStream: OutputStream? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    @SuppressLint("MissingPermission")
    fun connect(macAddress: String) {
        Thread {
            try {
                val adapter = BluetoothAdapter.getDefaultAdapter()
                    ?: throw IOException("البلوتوث غير مدعوم على هذا الجهاز")

                if (!adapter.isEnabled) {
                    throw IOException("فعّل البلوتوث أولاً")
                }

                val device: BluetoothDevice = adapter.getRemoteDevice(macAddress)
                adapter.cancelDiscovery()

                val tmpSocket = device.createRfcommSocketToServiceRecord(SPP_UUID)
                tmpSocket.connect()

                socket = tmpSocket
                outputStream = tmpSocket.outputStream

                mainHandler.post {
                    onStatusChanged(true)
                    onLog("تم الاتصال بنجاح")
                }
            } catch (e: Exception) {
                mainHandler.post {
                    onStatusChanged(false)
                    onLog("فشل الاتصال: ${e.message}")
                }
                closeQuietly()
            }
        }.start()
    }

    fun send(command: Char) {
        val out = outputStream
        if (out == null) {
            onLog("غير متصل")
            return
        }
        Thread {
            try {
                out.write(command.code)
                out.flush()
                mainHandler.post { onLog("تم إرسال: $command") }
            } catch (e: Exception) {
                mainHandler.post {
                    onLog("خطأ بالإرسال: ${e.message}")
                    onStatusChanged(false)
                }
            }
        }.start()
    }

    fun disconnect() {
        closeQuietly()
        onStatusChanged(false)
        onLog("تم قطع الاتصال")
    }

    private fun closeQuietly() {
        try { outputStream?.close() } catch (_: Exception) {}
        try { socket?.close() } catch (_: Exception) {}
        outputStream = null
        socket = null
    }
}
