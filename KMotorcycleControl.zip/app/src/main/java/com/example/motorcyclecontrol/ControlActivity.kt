package com.example.motorcyclecontrol

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.MotionEvent
import android.widget.Button
import android.widget.TextView
import android.view.View
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class ControlActivity : AppCompatActivity() {

    private lateinit var bluetoothHelper: BluetoothHelper
    private lateinit var macAddress: String

    private lateinit var statusDot: View
    private lateinit var statusText: TextView
    private lateinit var connectBtn: Button
    private lateinit var logText: TextView

    private lateinit var openBtn: Button
    private lateinit var closeBtn: Button
    private lateinit var starterBtn: Button
    private lateinit var killBtn: Button

    private var isConnected = false

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) connectToDevice()
        else appendLog("تحتاج صلاحية البلوتوث للاتصال")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_control)

        macAddress = intent.getStringExtra("MAC_ADDRESS") ?: ""

        statusDot = findViewById(R.id.statusDot)
        statusText = findViewById(R.id.statusText)
        connectBtn = findViewById(R.id.connectBtn)
        logText = findViewById(R.id.logText)
        openBtn = findViewById(R.id.openBtn)
        closeBtn = findViewById(R.id.closeBtn)
        starterBtn = findViewById(R.id.starterBtn)
        killBtn = findViewById(R.id.killBtn)

        findViewById<TextView>(R.id.macTag).text = "الجهاز: $macAddress"

        bluetoothHelper = BluetoothHelper(
            onStatusChanged = { connected -> runOnUiThread { setConnected(connected) } },
            onLog = { msg -> runOnUiThread { appendLog(msg) } }
        )

        connectBtn.setOnClickListener {
            if (isConnected) {
                bluetoothHelper.disconnect()
            } else {
                requestBluetoothPermissionAndConnect()
            }
        }

        // فتح / قفل السويتش
        openBtn.setOnClickListener { bluetoothHelper.send('O') }
        closeBtn.setOnClickListener { bluetoothHelper.send('F') }

        // إطفاء المحرك (نبضة واحدة، نفس منطق كود ESP32)
        killBtn.setOnClickListener { bluetoothHelper.send('E') }

        // زر السلف: اضغط مطوّل يرسل 'S' (تشغيل السلف)، رفع الإصبع يرسل '8' (إيقاف السلف)
        starterBtn.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> bluetoothHelper.send('S')
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> bluetoothHelper.send('8')
            }
            true
        }

        setConnected(false)
    }

    private fun requestBluetoothPermissionAndConnect() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val permission = Manifest.permission.BLUETOOTH_CONNECT
            if (ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED) {
                connectToDevice()
            } else {
                requestPermissionLauncher.launch(permission)
            }
        } else {
            connectToDevice()
        }
    }

    private fun connectToDevice() {
        appendLog("يتصل بـ $macAddress ...")
        bluetoothHelper.connect(macAddress)
    }

    private fun setConnected(connected: Boolean) {
        isConnected = connected
        statusDot.setBackgroundResource(
            if (connected) R.drawable.status_dot_connected else R.drawable.status_dot_disconnected
        )
        statusText.text = if (connected) "متصل" else "غير متصل"
        connectBtn.text = if (connected) "✅ متصل — اضغط لقطع الاتصال" else "🔗 اتصال بالجهاز"

        listOf(openBtn, closeBtn, starterBtn, killBtn).forEach { btn ->
            btn.isEnabled = connected
            btn.alpha = if (connected) 1f else 0.35f
        }
    }

    private fun appendLog(msg: String) {
        logText.text = "$msg\n${logText.text}"
    }

    override fun onDestroy() {
        super.onDestroy()
        bluetoothHelper.disconnect()
    }
}
