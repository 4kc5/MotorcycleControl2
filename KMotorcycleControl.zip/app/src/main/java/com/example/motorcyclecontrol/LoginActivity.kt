package com.example.motorcyclecontrol

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class LoginActivity : AppCompatActivity() {

    // غيّر كلمة السر من هنا
    private val APP_PASSWORD = "1234"
    private val MAC_REGEX = Regex("^([0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}$")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val macInput = findViewById<EditText>(R.id.macInput)
        val passInput = findViewById<EditText>(R.id.passInput)
        val errorText = findViewById<TextView>(R.id.errorText)
        val loginBtn = findViewById<Button>(R.id.loginBtn)

        loginBtn.setOnClickListener {
            val mac = macInput.text.toString().trim().uppercase()
            val pass = passInput.text.toString()

            when {
                !MAC_REGEX.matches(mac) -> {
                    errorText.text = "صيغة عنوان MAC غير صحيحة، مثال: AA:BB:CC:DD:EE:FF"
                }
                pass != APP_PASSWORD -> {
                    errorText.text = "كلمة السر غير صحيحة"
                }
                else -> {
                    errorText.text = ""
                    val intent = Intent(this, ControlActivity::class.java)
                    intent.putExtra("MAC_ADDRESS", mac)
                    startActivity(intent)
                }
            }
        }
    }
}
